import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonBuilder

def Message processData(Message message) {
    def backendResponse = new JsonSlurper().parseText(message.getBody(String) as String)
    def correlationId = message.getProperty("correlationId")

    def finalResponse = [
        orderNumber: backendResponse.Vbeln,
        status: backendResponse.Status,
        totalAmount: backendResponse.Netwr,
        correlationId: correlationId
    ]

    message.setBody(new JsonBuilder(finalResponse).toString())
    message.setHeader("Content-Type", "application/json")
    return message
}
