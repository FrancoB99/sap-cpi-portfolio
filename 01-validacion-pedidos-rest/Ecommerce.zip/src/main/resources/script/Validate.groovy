import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonBuilder
import java.util.UUID

def Message processData(Message message) {
    def body = message.getBody(String) as String
    def json = new JsonSlurper().parseText(body)
    def messageLog = messageLogFactory.getMessageLog(message)

    // --- Validaciones de negocio ---
    def errors = []
    if (!json.customerId) errors << "customerId es obligatorio"
    if (!json.items || json.items.isEmpty()) errors << "Debe enviar al menos un item"
    json.items?.each { item ->
        if (!item.materialId) errors << "materialId obligatorio en todos los items"
        if ((item.quantity ?: 0) <= 0) errors << "quantity debe ser mayor a 0 (material ${item.materialId})"
        if ((item.unitPrice ?: 0) < 0) errors << "unitPrice no puede ser negativo (material ${item.materialId})"
    }
    if (errors) {
        throw new IllegalArgumentException(errors.join(" | "))
    }

    // --- Enriquecimiento ---
    def totalAmount = json.items.sum { (it.quantity as BigDecimal) * (it.unitPrice as BigDecimal) }
    def correlationId = UUID.randomUUID().toString()

    json.totalAmount = totalAmount
    json.orderDate = new Date().format("yyyy-MM-dd")

    message.setProperty("correlationId", correlationId)
    message.setHeader("X-Correlation-Id", correlationId)

    if (messageLog != null) {
        messageLog.addAttachmentAsString("Payload-Enriquecido", new JsonBuilder(json).toPrettyString(), "application/json")
        messageLog.setStringProperty("CorrelationId", correlationId)
    }

    message.setBody(new JsonBuilder(json).toString())
    return message
}
