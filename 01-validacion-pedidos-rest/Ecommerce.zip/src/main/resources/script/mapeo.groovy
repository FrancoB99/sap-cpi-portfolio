import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonBuilder

def Message processData(Message message) {
    def json = new JsonSlurper().parseText(message.getBody(String) as String)

    def sapPayload = [
        Kunnr: json.customerId,
        Waerk: json.currency ?: "USD",
        Erdat: json.orderDate,
        Netwr: json.totalAmount,
        Items: json.items.collect { item ->
            [ Matnr: item.materialId, Menge: item.quantity, Netpr: item.unitPrice ]
        }
    ]

    message.setBody(new JsonBuilder(sapPayload).toString())
    message.setHeader("Content-Type", "application/json")
    return message
}