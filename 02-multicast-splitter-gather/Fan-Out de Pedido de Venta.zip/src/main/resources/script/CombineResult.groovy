import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper
import groovy.xml.StreamingMarkupBuilder

def Message processData(Message message) {
    def orderId = message.getProperty("orderId")
    def xml = new XmlSlurper().parseText(message.getBody(String) as String)

    def reasons = []
    def available = false
    def warehouse = ""
    def creditStatus = "UNKNOWN"
    def creditLimit = 0

    // chekeamos ambas posibilidades, el mensaje puede venir en cualquier orden luego de un join
    xml.children().each { msg ->
        def root = msg.root
        if (root.available.size() > 0) {
            available = root.available.text() == "true"
            warehouse = root.warehouse.text()
        } else if (root.creditStatus.size() > 0) {
            creditStatus = root.creditStatus.text()
            creditLimit = (root.creditLimit.text() ?: "0") as Integer
        }
    }

    if (!available) reasons << "Sin stock disponible"
    if (creditStatus != "APPROVED") reasons << "Crédito bloqueado para el cliente"

    def status = (available && creditStatus == "APPROVED") ? "CONFIRMED" : "ON_HOLD"
// construimos la respuesta combinada 
    def builder = new StreamingMarkupBuilder()
    def xmlFragment = builder.bind {
        Order {
            OrderId(orderId)
            Status(status)
            Warehouse(warehouse)
            CreditLimit(creditLimit)
            Reasons(reasons.join("; "))
        }
    }

    message.setBody(xmlFragment.toString())
    return message
}