import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper

def Message processData(Message message) {
    def xml = new XmlSlurper().parseText(message.getBody(String) as String)
    def messageLog = messageLogFactory.getMessageLog(message)
    
    // guardamos los campos para luego reconstruir el pedido
    message.setProperty("orderId", xml.orders.orderId.text())
    message.setProperty("customerId", xml.orders.customerId.text())
    message.setProperty("material", xml.orders.material.text())
    message.setProperty("quantity", xml.orders.quantity.text())
    message.setProperty("netValue", xml.orders.netValue.text())

    if (messageLog != null) {
        messageLog.setStringProperty("Procesando", "${xml.orders.orderId.text()} - ${xml.orders.customerId.text()}")
    }
    
    return message
}


