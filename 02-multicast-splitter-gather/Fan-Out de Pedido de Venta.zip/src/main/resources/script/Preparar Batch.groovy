import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def body = message.getBody(String) as String
    def json = new JsonSlurper().parseText(body)
    def messageLog = messageLogFactory.getMessageLog(message)

    if (!json.orders || json.orders.isEmpty()) {
        throw new IllegalArgumentException("El batch debe contener al menos un pedido")
    }
// guardamos los campos que se pierden con el splitter para luego reconstruir cada pedido
    def batchId = json.batchId ?: "BATCH-" + System.currentTimeMillis()
    message.setProperty("batchId", batchId)
    message.setProperty("totalOrdersCount", json.orders.size())

    if (messageLog != null) {
        messageLog.setStringProperty("BatchId", batchId)
        messageLog.setStringProperty("CantidadPedidos", json.orders.size().toString())
    }
    return message
}