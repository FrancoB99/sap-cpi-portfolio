import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder

def Message processData(Message message) {
    def exception = message.getProperty("CamelExceptionCaught")
    def errorMsg = exception ? exception.getMessage() : "Error desconocido en la integración"
    def batchId = message.getProperty("batchId") ?: "N/A"

    def messageLog = messageLogFactory.getMessageLog(message)
    if (messageLog != null) {
        messageLog.setStringProperty("ErrorDetail", errorMsg)
    }

    message.setBody(new JsonBuilder([
        status: "ERROR",
        message: errorMsg,
        batchId: batchId
    ]).toString())
    message.setHeader("CamelHttpResponseCode", 400)
    message.setHeader("Content-Type", "application/json")
    return message
}