import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder
import groovy.xml.XmlSlurper

def Message processData(Message message) {
    def xml = new XmlSlurper().parseText(message.getBody(String) as String)
    def messageLog = messageLogFactory.getMessageLog(message)

    def orders = []
    def confirmedCount = 0
    def onHoldCount = 0
// Recontruccion de cada pedido sumando su validacion
    xml.Order.each { order ->
        def status = order.Status.text()
        if (status == "CONFIRMED") { confirmedCount++ } else { onHoldCount++ }
        orders << [
            orderId: order.OrderId.text(),
            status: status,
            warehouse: order.Warehouse.text(),
            creditLimit: order.CreditLimit.text() as Integer,
            reasons: order.Reasons.text()
        ]
    }
// Pulido final del reporte
    def report = [
        processedAt: new Date().format("yyyy-MM-dd'T'HH:mm:ss"),
        totalOrders: orders.size(),
        confirmedCount: confirmedCount,
        onHoldCount: onHoldCount,
        orders: orders
    ]

    if (messageLog != null) {
        messageLog.setStringProperty("Resumen", "Confirmados: ${confirmedCount} / En espera: ${onHoldCount}")
    }

    message.setBody(new JsonBuilder(report).toString())
    message.setHeader("Content-Type", "application/json")
    return message
}
