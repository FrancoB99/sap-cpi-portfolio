import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import java.text.Normalizer

def Message processData(Message message) {
    def body = message.getBody(String) as String
    def odata = new JsonSlurper().parseText(body)
    def employees = odata.d?.results ?: []
    def messageLog = messageLogFactory.getMessageLog(message)

    if (employees.isEmpty()) {
        throw new IllegalStateException("SuccessFactors no devolvió empleados para procesar")
    }

    def sb = new StringBuilder()
    def today = new Date().format("yyyyMMdd")
    def companyCode = "AR01"

    sb << "HDR" << today << companyCode.padRight(4) << "\n"

    def totalSalary = 0.0G
// Generamos la respuesta tipo registro Detail, 99 caracteres, todo en posiciones fijas
// Header: HDR + fecha de proceso YYYYMMDD + código de compañía 4 chars 
// Trailer: TRL + cantidad de registros a 7 dígitos + suma total de salarios a 15 dígitos 
// Registros de control clásicos de cualquier interfaz batch.
    employees.each { emp ->
        def empId = (emp.personIdExternal ?: "").toString().take(10).padRight(10)
        def lastName = removeAccents(emp.lastName ?: "").toUpperCase().take(25).padRight(25)
        def firstName = removeAccents(emp.firstName ?: "").toUpperCase().take(25).padRight(25)
        def costCenter = (emp.costCenter ?: "").toString().take(10).padRight(10)
        def salary = emp.baseSalary as BigDecimal
        def salaryCents = (salary * 100).toBigInteger().toString().padLeft(15, '0')
        def currency = (emp.currency ?: "").toString().take(3).padRight(3)
        def hireDate = (emp.hireDate ?: "").toString().replace("-", "")

        sb << "DET" << empId << lastName << firstName << costCenter << salaryCents << currency << hireDate << "\n"
        totalSalary += salary
    }

    def totalCents = (totalSalary * 100).toBigInteger().toString().padLeft(15, '0')
    sb << "TRL" << employees.size().toString().padLeft(7, '0') << totalCents << "\n"

    if (messageLog != null) {
        messageLog.setStringProperty("RegistrosGenerados", employees.size().toString())
        messageLog.setStringProperty("TotalNomina", totalSalary.toString())
        messageLog.addAttachmentAsString("Archivo-Generado", sb.toString(), "text/plain")
    }

    message.setBody(sb.toString())
    message.setHeader("Content-Type", "text/plain")
    return message
}

// Saca tildes/ñ — el sistema destino legacy solo acepta ASCII
def removeAccents(String text) {
    def normalized = Normalizer.normalize(text, Normalizer.Form.NFD)
    return normalized.replaceAll(/\p{InCombiningDiacriticalMarks}+/, "")
}
