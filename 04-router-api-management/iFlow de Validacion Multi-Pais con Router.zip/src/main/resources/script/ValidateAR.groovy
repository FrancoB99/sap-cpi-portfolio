import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonBuilder

def Message processData(Message message) {
    def countryCode = message.getProperty("countryCode") as String
    def taxId = message.getProperty("taxId") as String

    def rules = [
        AR: [regex: /\d{11}/, rule: "CUIT"],
        BR: [regex: /\d{14}/, rule: "CNPJ"],
        MX: [regex: /[A-Z0-9]{12,13}/, rule: "RFC"]
    ]

    def ruleConfig = rules[countryCode]
    def isValid = taxId ==~ ruleConfig.regex

    def result = [
        countryCode: countryCode,
        taxId: taxId,
        valid: isValid,
        ruleApplied: ruleConfig.rule,
        message: isValid ? "Formato válido" : "El ${ruleConfig.rule} no tiene el formato esperado"
    ]

    message.setBody(new JsonBuilder(result).toString())
    message.setHeader("Content-Type", "application/json")
    return message
}
