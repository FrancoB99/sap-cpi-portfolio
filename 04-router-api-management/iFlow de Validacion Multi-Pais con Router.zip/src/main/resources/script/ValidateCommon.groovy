import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    def json = new JsonSlurper().parseText(message.getBody(String) as String)
    def messageLog = messageLogFactory.getMessageLog(message)

    def errors = []
    if (!json.countryCode) errors << "countryCode es obligatorio"
    if (!json.taxId || json.taxId.toString().length() < 5) errors << "taxId inválido o ausente"
    if (!json.customerName) errors << "customerName es obligatorio"

    if (errors) {
        throw new IllegalArgumentException(errors.join(" | "))
    }
// guardamos los datos de la entrada en propiedades
    message.setProperty("countryCode", json.countryCode)
    message.setProperty("taxId", json.taxId)
    message.setProperty("customerName", json.customerName)

    if (messageLog != null) {
        messageLog.setStringProperty("Pais", json.countryCode as String)
    }
    return message
}
