import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def countryCode = message.getProperty("countryCode")
    throw new IllegalArgumentException("País no soportado: ${countryCode}")
}