import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import java.text.Normalizer

def Message processData(Message message) {
    def odata = new JsonSlurper().parseText(message.getBody(String) as String)
    def employees = odata.d?.results ?: []
    def messageLog = messageLogFactory.getMessageLog(message)

    if (employees.isEmpty()) {
        throw new IllegalStateException("SuccessFactors no devolvió empleados para procesar")
    }

    def sb = new StringBuilder()
    def today = new Date().format("yyyyMMdd")
    def companyCode = "AR01"

    sb << "HDR" << today << companyCode.padRight(4) << "\n"

    employees.each { emp ->
        sb << "DET"
        sb << fit(emp.userId, 10)
        sb << fit(clean(emp.lastName), 25)
        sb << fit(clean(emp.firstName), 25)
        sb << fit(clean(emp.department), 20)
        sb << fit(clean(emp.title), 25)
        sb << odataDate(emp.hireDate)
        sb << "\n"
    }

    sb << "TRL" << employees.size().toString().padLeft(7, '0') << "\n"

    if (messageLog != null) {
        messageLog.setStringProperty("RegistrosGenerados", employees.size().toString())
        messageLog.addAttachmentAsString("Archivo-Generado", sb.toString(), "text/plain")
    }

    message.setBody(sb.toString())
    message.setHeader("Content-Type", "text/plain")
    return message
}

// Trunca y rellena a ancho fijo
def fit(value, int width) {
    return (value ?: "").toString().take(width).padRight(width)
}

// Mayúsculas y sin tildes/ñ (destino legacy solo ASCII)
def clean(value) {
    def normalized = Normalizer.normalize((value ?: "").toString(), Normalizer.Form.NFD)
    return normalized.replaceAll(/\p{InCombiningDiacriticalMarks}+/, "").toUpperCase()
}

// OData v2 devuelve fechas como /Date(1262304000000)/ -> YYYYMMDD
def odataDate(value) {
    def text = (value ?: "").toString()
    def m = text =~ /\/Date\((-?\d+)/
    if (m.find()) {
        return new Date(m.group(1) as Long).format("yyyyMMdd", TimeZone.getTimeZone("UTC"))
    }
    return text.replace("-", "").take(8).padRight(8)
}
