import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def exception = message.getProperty("CamelExceptionCaught")
    def errorMsg = exception ? exception.getMessage() : "Error desconocido en la extracción de empleados"

    def messageLog = messageLogFactory.getMessageLog(message)
    if (messageLog != null) {
        messageLog.setStringProperty("ErrorDetail", errorMsg)
    }

    message.setBody("Error en la extracción de empleados: ${errorMsg}")
    return message
}
